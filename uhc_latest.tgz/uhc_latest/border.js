// ============================================================================
//  UHC Core - البوردر الديناميكي
//  🔧 الجديد: يهدى خلال التوزيع │ السايدبار ما يفشي مواقع اللاعبين ويتنظف كامل
//     │ وضع title يحترم قفل التايتل │ سرعة الانكماش تظهر صح
// ============================================================================
import { world } from "@minecraft/server";
import { CONFIG } from "./config.js";
import { State } from "./state.js";
import { isRespawnActive, respawnTimeLeft, Respawn } from "./respawn.js";
import {
  titleAll, soundAll, soundOnce, actionBar, formatMs,
  dimScale, isSpectatorLike, clamp, CAUSE_MAGIC, titleLocked,
} from "./util.js";

export function shrinkInfo() {
  const b = State.data.border;
  if (!b.shrinking || b.shrinkDurationMs <= 0) {
    return {
      active: false, remainingMs: 0, remainingBlocks: 0,
      speedPerSec: 0, target: Math.floor(b.shrinkTargetHalf),
    };
  }
  const elapsed = clamp(Date.now() - b.shrinkStartAt, 0, b.shrinkDurationMs);
  const remainingMs = b.shrinkDurationMs - elapsed;
  const totalBlocks = Math.max(0, b.shrinkFromHalf - b.shrinkTargetHalf);
  return {
    active: true,
    remainingMs,
    remainingBlocks: Math.ceil(Math.max(0, b.currentHalf - b.shrinkTargetHalf)),
    speedPerSec: Math.round((totalBlocks / (b.shrinkDurationMs / 1000)) * 10) / 10,
    target: Math.floor(b.shrinkTargetHalf),
  };
}

function directionLabel(b, loc, scale) {
  const x = loc.x * scale, z = loc.z * scale;
  const edges = [
    { d: Math.abs(x - (b.centerX + b.currentHalf)), label: "شرق" },
    { d: Math.abs(x - (b.centerX - b.currentHalf)), label: "غرب" },
    { d: Math.abs(z - (b.centerZ + b.currentHalf)), label: "جنوب" },
    { d: Math.abs(z - (b.centerZ - b.currentHalf)), label: "شمال" },
  ];
  edges.sort((a, c) => a.d - c.d);
  return edges[0].label;
}

export const Border = {
  // ---------------------------------------------------------------- انكماش
  startShrink(opts = {}) {
    const b = State.data.border;
    const amount = Math.max(0, Math.floor(opts.amount ?? b.cfgShrinkAmount ?? b.shrinkAmount));
    const durationMs = Math.max(1000, Math.floor(opts.durationMs ?? b.cfgShrinkDurationMs ?? b.shrinkDurationMs));

    if (amount <= 0) return { ok: false, reason: "no_amount" };
    if (b.currentHalf <= CONFIG.minBorderHalf) return { ok: false, reason: "at_minimum" };

    b.shrinkFromHalf = b.currentHalf;
    b.shrinkTargetHalf = Math.max(CONFIG.minBorderHalf, b.currentHalf - amount);
    b.shrinkAmount = amount;
    b.shrinkDurationMs = durationMs;
    b.shrinkStartAt = Date.now();
    b.pausedRemainingMs = 0;
    b.shrinking = true;
    State.save();

    if (!opts.silent) {
      titleAll("§c§l⚠ البوردر بدأ ينكمش!",
        `§7-${amount} بلوك خلال ${formatMs(durationMs)} → ±${Math.floor(b.shrinkTargetHalf)}`);
      soundAll(CONFIG.soundShrinkStart, 1.0, 0.8);
    }
    return { ok: true, amount, durationMs, target: Math.floor(b.shrinkTargetHalf) };
  },

  pauseShrink() {
    const b = State.data.border;
    if (!b.shrinking) return false;
    b.pausedRemainingMs = Math.max(0, b.shrinkStartAt + b.shrinkDurationMs - Date.now());
    b.shrinking = false;
    State.save();
    return true;
  },

  resumeShrink() {
    const b = State.data.border;
    if (b.shrinking) return false;
    if (b.shrinkTargetHalf >= b.currentHalf - 0.01) return false;

    if (b.pausedRemainingMs <= 0) {
      b.currentHalf = Math.max(CONFIG.minBorderHalf, b.shrinkTargetHalf);
      State.save();
      return true;
    }
    b.shrinkFromHalf = b.currentHalf;
    b.shrinkDurationMs = b.pausedRemainingMs;
    b.shrinkStartAt = Date.now();
    b.pausedRemainingMs = 0;
    b.shrinking = true;
    State.save();
    return true;
  },

  finishShrink() {
    const b = State.data.border;
    b.shrinking = false;
    b.pausedRemainingMs = 0;
    b.currentHalf = Math.max(CONFIG.minBorderHalf, b.shrinkTargetHalf);
    b.shrinkAmount = b.cfgShrinkAmount;
    b.shrinkDurationMs = b.cfgShrinkDurationMs;
    State.save();
    titleAll("§a§lالبوردر ثبت", `§7الحجم §f${Math.floor(b.currentHalf)}`);
    soundAll(CONFIG.soundShrinkEnd, 1.0, 1.2);
  },

  // يرجع { value, cancelled } — cancelled = ألغينا انكماش جاري
  setSize(half, { alsoStart = true } = {}) {
    const b = State.data.border;
    const cancelled = b.shrinking;
    const v = clamp(Math.floor(half), CONFIG.minBorderHalf, 30000000);
    b.currentHalf = v;
    b.shrinkFromHalf = v;
    b.shrinkTargetHalf = v;
    b.shrinking = false;
    b.pausedRemainingMs = 0;
    if (alsoStart) b.startHalf = v;
    State.save();
    return { value: v, cancelled };
  },

  // ---------------------------------------------------------------- مسافات
  signedDistanceOut(player) {
    const b = State.data.border;
    const s = dimScale(player.dimension.id);
    const dx = Math.abs(player.location.x * s - b.centerX);
    const dz = Math.abs(player.location.z * s - b.centerZ);
    return Math.max(dx, dz) - b.currentHalf;
  },

  isOutside(player) { return this.signedDistanceOut(player) > 0; },

  // ---------------------------------------------------------------- الدورة
  tick() {
    const s = State.data;
    if (s.phase === "LOBBY" || s.phase === "ENDED") { this.clearSidebar(); return; }
    // 🔧 خلال التوزيع: ماكو ضرر ولا HUD ولا جزيئات (اللاعبين طايرين بالسمى)
    if (Date.now() < (s.scatterUntil ?? 0)) return;

    const b = s.border;
    const now = Date.now();

    if (b.shrinking && b.shrinkDurationMs > 0) {
      const t = clamp((now - b.shrinkStartAt) / b.shrinkDurationMs, 0, 1);
      const span = b.shrinkFromHalf - b.shrinkTargetHalf;
      b.currentHalf = Math.max(CONFIG.minBorderHalf, b.shrinkFromHalf - span * t);
      if (t >= 1) this.finishShrink();
      else State.markDirty();
    }

    const info = shrinkInfo();
    const graceActive = s.phase === "GRACE" && now < s.grace.endAt;
    const damage = b.damage ?? CONFIG.damageOutsideBorder;
    const mode = s.hud?.mode ?? "actionbar";

    for (const p of world.getPlayers()) {
      let dist;
      try { dist = this.signedDistanceOut(p); } catch { continue; }

      const passive = isSpectatorLike(p) || State.isEliminated(p.name);

      if (!passive && !graceActive && dist > 0) {
        try { p.applyDamage(damage, { cause: CAUSE_MAGIC }); } catch {}
        actionBar(p, `§c§lانت بره البوردر §8| §cارجع حالا §8| §f${Math.ceil(dist)} §7بلوك`);
        soundOnce(p, CONFIG.soundOutside, CONFIG.soundOutsideTicks, 1.0, 0.6);
      } else {
        // 🔧 الأكشن بار يشتغل دايماً — حتى بوضع scoreboard (المسافة شخصية)
        if (CONFIG.hudEnabled !== false && State.data.hud?.off !== true) {
          this.renderHud(p, this.hudText(p, dist, info, graceActive, passive), mode);
        }
        if (!passive && CONFIG.soundNearBorderEnabled && dist > -CONFIG.borderWarningDistance && dist <= 0) {
          const closeness = clamp(1 - (-dist / CONFIG.borderWarningDistance), 0, 1);
          const pitch = 0.8 + closeness * 0.8;
          const interval = Math.max(20, Math.floor(CONFIG.soundNearBorderTicks * (1 - closeness * 0.6)));
          soundOnce(p, CONFIG.soundNearBorder, interval, 0.7, pitch);
        }
      }

      if (CONFIG.wallEnabled && dist > -CONFIG.wallViewDistance) {
        try { this.drawBorderNear(p); } catch {}
      }
    }

    if (mode === "scoreboard") { try { this.sidebarTick(info, graceActive); } catch {} }
    else this.clearSidebar();
  },

  // ------------------------------------------------- عرض
  renderHud(player, text, mode) {
    if (mode === "title") {
      if (titleLocked(player)) return;          // 🔧 ما نمسح التايتلات المهمة
      try {
        player.onScreenDisplay.setTitle(" ", {
          subtitle: text, fadeInDuration: 0, stayDuration: 25, fadeOutDuration: 0,
        });
      } catch {}
      return;
    }
    actionBar(player, text);
  },

  _sbShown: false,
  _sbLines: [],

  clearSidebar() {
    // 🔧 ما نعتمد على _sbShown (يصفّر بالريستارت والسايدبار يبقى معلق)
    if (this._sbShown === false && this._sbLines.length === 0) {
      try {
        if (!world.scoreboard.getObjective(CONFIG.scoreboardObjective)) return;
      } catch { return; }
    }
    this._sbShown = false;
    this._sbLines = [];
    try { world.scoreboard.clearObjectiveAtDisplaySlot("Sidebar"); } catch {}
    try { world.scoreboard.removeObjective(CONFIG.scoreboardObjective); } catch {}
  },

  // ⚠️ السكوربورد عام للكل → معلومات مشتركة بس، ماكو مواقع لاعبين
  sidebarTick(info, grace) {
    const sb = world.scoreboard, id = CONFIG.scoreboardObjective;
    let obj;
    try { obj = sb.getObjective(id); } catch {}
    if (!obj) { try { obj = sb.addObjective(id, "§6UHC"); } catch { return; } }
    if (!this._sbShown) {
      try { sb.setObjectiveAtDisplaySlot("Sidebar", { objective: obj }); } catch {}
      this._sbShown = true;
    }
    const s = State.data, b = s.border;
    const L = [`§eالبوردر §f${Math.floor(b.currentHalf)}`];
    const moved = Math.max(0, Math.floor((b.startHalf ?? b.currentHalf) - b.currentHalf));
    if (moved > 0) L.push(`§7تحرك §f${moved}`);
    if (info.active) {
      L.push(`§c${info.speedPerSec} §7بالثانية`);
      L.push(`§7الهدف §f${info.target}`);
    } else if (grace) L.push(`§aسماح §f${formatMs(s.grace.endAt - Date.now())}`);
    L.push(isRespawnActive() ? `§aترجع §f${respawnTimeLeft()}` : "§cموت نهائي");
    L.push(`§aعايشين §f${Respawn.aliveCount()}`);

    const cl = L.map(x => x.slice(0, 40));
    if (cl.length === this._sbLines.length && cl.every((x, i) => x === this._sbLines[i])) return;
    const want = new Set(cl);
    try {
      for (const q of obj.getScores())
        if (!want.has(q.participant?.displayName ?? ""))
          { try { obj.removeParticipant(q.participant); } catch {} }
    } catch {}
    let n = cl.length;
    for (const x of cl) { try { obj.setScore(x, n--); } catch {} }
    this._sbLines = cl;
  },

  hudText(player, dist, info, graceActive, passive) {
    const s = State.data, b = s.border;
    const sc = dimScale(player.dimension.id);
    const alive = Respawn.aliveCount();
    if (passive) return `§cخرجت من اللعبة §8| §7عايشين §a${alive}`;

    const d = Math.max(0, Math.ceil(-dist));
    const dir = directionLabel(b, player.location, sc);
    const near = dist > -CONFIG.borderWarningDistance;
    let t = near ? `§c§lالبوردر §f${d} §c${dir}` : `§bالبوردر §f${d} §7${dir}`;
    if (sc !== 1) t += " §8(نذر)";

    if (info.active) t += ` §8| §c${info.speedPerSec} §7بالثانية`;
    else if (graceActive) t += ` §8| §aسماح ${formatMs(s.grace.endAt - Date.now())}`;
    else t += ` §8| §7ثابت ${Math.floor(b.currentHalf)}`;

    const moved = Math.max(0, Math.floor((b.startHalf ?? b.currentHalf) - b.currentHalf));
    if (moved > 0) t += ` §8| §7تحرك §f${moved}`;

    t += isRespawnActive() ? ` §8| §aترجع ${respawnTimeLeft()}` : " §8| §cموت نهائي";
    t += ` §8| §aعايشين ${alive}`;
    return t;
  },

  // ------------------------------------------------------- السور المرئي
  drawBorderNear(player) {
    const b = State.data.border;
    const dim = player.dimension;
    if (dimScale(dim.id) !== 1) return;          // النذر: الإحداثيات مضغوطة

    const loc = player.location;
    const px = Math.floor(loc.x), py = Math.floor(loc.y), pz = Math.floor(loc.z);

    const edges = [
      { fixed: b.centerX + b.currentHalf, axis: "x" },
      { fixed: b.centerX - b.currentHalf, axis: "x" },
      { fixed: b.centerZ + b.currentHalf, axis: "z" },
      { fixed: b.centerZ - b.currentHalf, axis: "z" },
    ];
    let best = edges[0], bestDist = Infinity;
    for (const e of edges) {
      const d = e.axis === "x" ? Math.abs(loc.x - e.fixed) : Math.abs(loc.z - e.fixed);
      if (d < bestDist) { bestDist = d; best = e; }
    }
    if (bestDist > CONFIG.wallViewDistance) return;

    let view = { x: 0, y: 0, z: 0 };
    try { view = player.getViewDirection(); } catch {}
    const along = best.axis === "x" ? view.z : view.x;
    const center = (best.axis === "x" ? pz : px) + Math.round(along * 12);
    const fixed = Math.floor(best.fixed);

    let budget = CONFIG.particleBudgetPerPlayer;
    const emit = (pos) => {
      if (budget-- <= 0) return false;
      try { dim.spawnParticle(CONFIG.borderParticle, pos); } catch {}
      return true;
    };

    if (bestDist <= CONFIG.wallNearDistance) {
      for (let y = py - CONFIG.wallBelow; y <= py + CONFIG.wallAbove; y += CONFIG.wallStepY) {
        for (let o = -CONFIG.wallHalfWidth; o <= CONFIG.wallHalfWidth; o += CONFIG.wallStepX) {
          const c = center + o;
          if (!emit(best.axis === "x" ? { x: fixed, y, z: c } : { x: c, y, z: fixed })) return;
        }
      }
    } else {
      const span = CONFIG.wallHalfWidth * 2;
      for (let o = -span; o <= span; o += CONFIG.wallPillarSpacing) {
        const c = center + o;
        for (let y = py - 2; y <= py + CONFIG.wallPillarHeight; y += CONFIG.wallPillarStep) {
          if (!emit(best.axis === "x" ? { x: fixed, y, z: c } : { x: c, y, z: fixed })) return;
        }
      }
    }
  },

  statusText() {
    const b = State.data.border;
    const info = shrinkInfo();
    let t = `البوردر: ±${Math.floor(b.currentHalf)} عند (${b.centerX}, ${b.centerZ})`;
    if (info.active) {
      t += ` | ينكمش ${info.speedPerSec} بلوك/ث → ±${info.target} خلال ${formatMs(info.remainingMs)}`;
    }
    return t;
  },
};
